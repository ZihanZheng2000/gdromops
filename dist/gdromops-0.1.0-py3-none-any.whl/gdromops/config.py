
# GitHub raw base for your rules repository
DEFAULT_RULES_BASE = "https://raw.githubusercontent.com/ZihanZheng2000/gdrom-v2-rules/main"
TIMEOUT = 20
